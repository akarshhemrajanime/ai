<?php

function post_article_to_wordpress($title, $content, $categories,$post_date,$focus_keywords,$meta_description,$image_count,$add_related_posts,$saveImage) {
    $post_data = array(
        'post_title'    => wp_strip_all_tags($title),
        'post_content'  => $content,
        'post_status'   => 'publish',
        'post_author'   => 1, // ID author
        'post_category' => $categories, // Use selected category IDs
        'post_date_gmt' => $post_date
    );

    // Insert the post into the database
    $post_id = wp_insert_post($post_data, true);
    if (is_wp_error($post_id)) {
        // Log error and return status code
        error_log('Failed to insert post: ' . $post_id->get_error_message());
        return $post_id->get_error_message(); // Return error message
    } else {
        // Update SEO metadata
        update_seo_meta($post_id, $title, $content, $focus_keywords, $meta_description);
        $image_urls = scrape_bing_images($title, $image_count);
        

        // Handle the first image URL as the featured image (future image)
        if (isset($image_urls[0])) {
            $featured_image_id = download_and_attach_image($image_urls[0], $post_id, 'Featured image for ' . $title);

            if ($featured_image_id) {
                set_post_thumbnail($post_id, $featured_image_id);
            }
        }

        // Handle the second image URL as the content image
        if (isset($image_urls[1])) {
            if ($saveImage === 1) {
                // Download dan lampirkan gambar ke WordPress
                $content_image_id = download_and_attach_image($image_urls[1], $post_id, 'Content image for ' . $title);
                
                if ($content_image_id) {
                    $image_html = wp_get_attachment_image($content_image_id, 'full', false, [
                        'class' => 'aligncenter'
                    ]);
                    $content_update = $image_html . "\n\n" . $content;
                }
            } else {
                // Menggunakan URL gambar langsung tanpa menyimpan
                $image_html = '<img src="' . esc_url($image_urls[1]) . '" class="aligncenter" alt="Content image for ' . esc_attr($title) . '">';
                $content_update = $image_html . "\n\n" . $content;
            }
        } else {
            $content_update = $content;
        }

        // Check if related posts should be added
        if ($add_related_posts == 1) {
            $related_posts_html = get_related_posts($categories, $post_id);
            if ($related_posts_html) {
                // Insert after the fifth paragraph
                $content_parts = explode('</p>', $content_update);
                if (count($content_parts) > 5) {
                    // Insert related posts after the fifth paragraph
                    $content_parts[4] .= '</p>' . $related_posts_html; // Tambahkan di paragraf ke-5
                } else {
                    // If there are not enough paragraphs, just add at the end
                    $content_parts[0] .= $related_posts_html;
                }
                // Combine back the content
                $final_content = implode('</p>', $content_parts);
            } else {
                $final_content = $content_update; // No related posts found
            }
        } else {
            $final_content = $content_update; // No related posts to add
        }

        // Update the post content
        wp_update_post(array(
            'ID'           => $post_id,
            'post_content' => $final_content
        ));

        // Return success status code
        return 201; // HTTP status code for Created
    }
}

function get_related_posts($categories, $post_id) {
    // Mengambil satu artikel terkait berdasarkan kategori yang sudah dipublikasikan
    $args = array(
        'category__in' => $categories,
        'post__not_in' => array($post_id),
        'posts_per_page' => 1, // Hanya mengambil satu artikel
        'post_status' => 'publish' // Hanya ambil yang sudah dipublikasikan
    );
    
    $related_post = new WP_Query($args);
    if ($related_post->have_posts()) {
        $related_post->the_post();
        $related_post_html = '<p style="font-size: 0.9em; font-weight: bold;">Related Post : <a href="' . get_permalink() . '" style="color: #0073aa; text-decoration: underline;">' . get_the_title() . '</a></p>';
        wp_reset_postdata();
        return $related_post_html;
    }
    return '';
}

// function update_yoast_seo_meta($post_id, $title, $content, $focus_keywords,$meta_description) {
//     if (defined('WPSEO_VERSION')) {
//         // Set SEO title
//         update_post_meta($post_id, '_yoast_wpseo_title', $title);

//         // Generate or set a meta description (e.g., the first 155 characters of the content)
//         update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);

//         // Generate or set focus keywords
//         update_post_meta($post_id, '_yoast_wpseo_focuskw', $focus_keywords);
//     } else {
//         // Yoast SEO is not installed or active
//         error_log('Yoast SEO is not installed or active. Skipping SEO metadata update for post ID ' . $post_id);
//     }
// }

function update_seo_meta($post_id, $title, $content, $focus_keywords, $meta_description) {
    // Update Yoast SEO metadata
    if (defined('WPSEO_VERSION')) {
        update_post_meta($post_id, '_yoast_wpseo_title', $title);
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
        update_post_meta($post_id, '_yoast_wpseo_focuskw', $focus_keywords);
    }

    // Update Rank Math metadata
    if (defined('RANK_MATH_VERSION')) {
        update_post_meta($post_id, 'rank_math_title', $title);
        update_post_meta($post_id, 'rank_math_description', $meta_description);
        update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keywords);
    }

    // Update All in One SEO metadata
    if (defined('AIOSEOP_VERSION')) {
        update_post_meta($post_id, '_aioseop_title', $title);
        update_post_meta($post_id, '_aioseop_description', $meta_description);
        // AIOSEO focus keyword might require additional setup depending on the version
    }
}

function get_wordpress_categories() {
    $categories = get_categories(array(
        'hide_empty' => false, 
    ));
    
    $options = array();
    foreach ($categories as $category) {
        $options[$category->term_id] = $category->name;
    }
    return $options;
}

function download_and_attach_image($image_url, $post_id, $alt_text) {
    // Ensure the image URL is well-formed
    $image_url = esc_url_raw($image_url);

    // Get image data from URL
    $response = wp_remote_get($image_url);
    if (is_wp_error($response)) {
        error_log('Failed to download image: ' . $response->get_error_message());
        return false;
    }

    // Check for valid response and retrieve image data
    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code != 200) {
        error_log('Failed to download image. HTTP Status Code: ' . $status_code);
        return false;
    }

    $image_data = wp_remote_retrieve_body($response);
    if (empty($image_data)) {
        error_log('Image data is empty.');
        return false;
    }

    // Determine file extension from URL or response headers
    $file_info = wp_check_filetype($image_url);
    $file_ext = $file_info['ext'] ?: 'jpg'; // Default to 'jpg' if no extension found

    // Generate a unique filename to prevent conflicts
    $filename = uniqid() . '.' . $file_ext;

    // Prepare upload
    $upload = wp_upload_bits($filename, null, $image_data);
    if ($upload['error']) {
        error_log('Failed to upload image: ' . $upload['error']);
        return false;
    }

    // Prepare attachment data
    $attachment = array(
        'post_mime_type' => wp_check_filetype($upload['file'])['type'],
        'post_title'     => sanitize_file_name(pathinfo($upload['file'], PATHINFO_FILENAME)),
        'post_content'   => '',
        'post_status'    => 'inherit'
    );

    // Insert the attachment into the media library
    $attachment_id = wp_insert_attachment($attachment, $upload['file'], $post_id);
    if (is_wp_error($attachment_id)) {
        error_log('Failed to insert attachment: ' . $attachment_id->get_error_message());
        return false;
    }

    // Generate attachment metadata
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload['file']);
    
    if (!$attachment_data) {
        error_log('Failed to generate attachment metadata. File: ' . $upload['file']);
        return false;
    }

    // Debugging output for attachment data
    error_log('Attachment Data for ID ' . $attachment_id . ': ' . print_r($attachment_data, true));

    // Attempt to update attachment metadata
    $metadata_updated = wp_update_attachment_metadata($attachment_id, $attachment_data);
    
    if (!$metadata_updated) {
        error_log('Failed to update attachment metadata. Attachment ID: ' . $attachment_id);
        // Additional debugging information
        $upload_dir = wp_upload_dir();
        error_log('Upload Directory: ' . print_r($upload_dir, true));
    } else {
        error_log('Attachment metadata updated successfully. Attachment ID: ' . $attachment_id);
    }

    // Optionally set alt text
    if (!update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text)) {
        error_log('Failed to update attachment alt text. Attachment ID: ' . $attachment_id);
    }

    return $attachment_id;
}

