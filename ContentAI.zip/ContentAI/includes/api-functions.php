<?php

function markdown_to_html($markdown) {
    // Convert Markdown headings to HTML
    $markdown = preg_replace_callback('/^(#{1,6})\s*(.+)$/m', function ($matches) {
        $level = strlen($matches[1]);
        return "<h$level>" . htmlspecialchars($matches[2]) . "</h$level>";
    }, $markdown);

    // Convert Markdown bold and italic
    $markdown = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $markdown);
    $markdown = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $markdown);

    // Convert Markdown links
    $markdown = preg_replace('/\[([^\]]+)\]\(([^\)]+)\)/', '<a href="$2">$1</a>', $markdown);

    // Convert Markdown images
    $markdown = preg_replace('/!\[([^\]]*)\]\(([^\)]+)\)/', '<img src="$2" alt="$1">', $markdown);

    // Convert Markdown lists
    $markdown = preg_replace('/^\s*\*\s*(.+)$/m', '<ul><li>$1</li></ul>', $markdown);
    $markdown = preg_replace('/<\/ul>\s*<ul>/', '', $markdown); // Remove nested lists issues

    // Convert Markdown blockquotes
    $markdown = preg_replace('/^>\s*(.+)$/m', '<blockquote>$1</blockquote>', $markdown);

    // Convert Markdown code blocks
    $markdown = preg_replace('/```(.*?)```/s', '<pre><code>$1</code></pre>', $markdown);

    // Convert Markdown inline code
    $markdown = preg_replace('/`([^`]+)`/', '<code>$1</code>', $markdown);

    // Convert Markdown horizontal rules
    $markdown = preg_replace('/^\s*---\s*$/m', '<hr>', $markdown);

    // Convert Markdown paragraphs (basic implementation)
    $markdown = '<p>' . preg_replace('/\n\s*\n/', '</p><p>', trim($markdown)) . '</p>';

    return $markdown;
}

function markdown_clear($text) {
    // Remove Markdown headers
    $text = preg_replace('/^#{1,6}\s+/m', '', $text);

    // Remove Markdown bold and italic
    $text = preg_replace('/(\*\*|__)(.*?)\1/', '$2', $text);
    $text = preg_replace('/(\*|_)(.*?)\1/', '$2', $text);

    // Remove Markdown links
    $text = preg_replace('/\[(.*?)\]\((.*?)\)/', '$1', $text);

    // Remove Markdown images
    $text = preg_replace('/!\[(.*?)\]\((.*?)\)/', '', $text);

    // Remove Markdown blockquotes
    $text = preg_replace('/^>\s+/m', '', $text);

    // Remove Markdown code blocks and inline code
    $text = preg_replace('/```.*?```/s', '', $text); // Code blocks
    $text = preg_replace('/`(.*?)`/', '$1', $text); // Inline code

    // Remove Markdown lists
    $text = preg_replace('/^\s*[-+*]\s+/m', '', $text);

    // Remove Markdown horizontal rules
    $text = preg_replace('/^\s*[-*]{3,}\s*$/m', '', $text);

    // Remove extra newlines and trim
    $text = preg_replace('/\n\s*\n/', "\n", $text); // Replace multiple newlines with a single newline
    $text = trim($text);

    return $text;
}

function get_keyword_suggestions($title, $api_key, $language) {
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-002:generateContent?key=' . $api_key;

    $prompt = "Buatkan 3 keyword dari judul ".$title." menggunakan ".$language.". Keyword yang dihasilkan adalah satu kata atau dua kata. Tuliskan keyword secara langsung dengan format : keyword utama, keyword pendukung 1, keyword pendukung 2,keyword pendukung 3. Keyword utama haruslah ada dalam judul.";

    $data = array(
        'contents' => array(
            array(
                'parts' => array(
                    array(
                        'text' => $prompt
                    )
                )
            )
        )
    );

    $response = wp_remote_post($url, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode($data),
        'timeout' => 60
    ));

    if (is_wp_error($response)) {
        error_log('API request error: ' . $response->get_error_message());
        return array();
    }

    $body = wp_remote_retrieve_body($response);
    $decoded = json_decode($body, true);
    // die(json_encode($decoded));
    if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
        return explode(',', $decoded['candidates'][0]['content']['parts'][0]['text']);
    } else {
        error_log('API response error: ' . print_r($decoded, true));
        return array();
    }
}


// Function to handle API errors and generate MECE outline
function generate_mece_outline($title, $api_key,$keywords, $language) {
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-002:generateContent?key=' . $api_key;
    $custom_prompt = get_option('custom_prompt_outline_option', null);
    $prompt = $custom_prompt ? str_replace(
        ['[judul]', '[bahasa]', '[keyword]'],
        [$title, $language, $keywords],
        $custom_prompt
    ) : "Your first task is to write an in-depth and comprehensive blog post outline for an article about: ".$title.".
    Keep in mind this is also the target keyword (".$keywords.") we are trying to rank for so include it and variations of the keyword in the h1,h2,h3 and throughout the article. 
    Create an in-depth blog post outline with every single question or topic a person would have for this blog post topic. 
    Include information specific to topic you are writing about but also general information about the blog post topic that would be useful for readers. 
    write in a simple, easy to read tone.
    
    for the format sample:

    Heading 1
    Heading 2
    Heading 3
    Heading 3
    Heading 2
    Heading 3
    Heading 3
    Heading 2
    Heading 3
    Heading 3
    conclusion
    
    use the format sample to implement outline.
    Dont repeat this prompt, dont apologize, and dont explain what and why. ";
    
    $data = array(
        'systemInstruction' => array(
            'role' => 'user',
            'parts' => array(
                array(
                    'text' => "saya ingin kamu menjadi penulis SEO yang profesional dan friendly, agar artikel saya nanti bisa masuk halaman pencarian dan bersaing di halaman pertama. tulisan kamu haruslah unik dan menggunakan gaya penulisan manusia. jangan menggunakan gaya penulisan AI. buatlah setidaknya kesalahan tanda baca seperti penggunaan koma, titik, tanda tanya, tanda seru di jeda spasi satu kali sebelum penggunaan tanda."
                )
            )
        ),
        'contents' => array(
            array(
                'parts' => array(
                    array(
                        'text' => $prompt
                    )
                )
            )
        ),
        'generationConfig' => array(
            'temperature' => 0.9,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 8192,
            'responseMimeType' => 'text/plain'
        )
    );

    $response = wp_remote_post($url, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode($data),
        'timeout' => 60
    ));

    if (is_wp_error($response)) {
        error_log('API request error: ' . $response->get_error_message());
        return '';
    }

    $body = wp_remote_retrieve_body($response);
    $decoded = json_decode($body, true);
    // die(json_encode($decoded));
    if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
        return markdown_clear($decoded['candidates'][0]['content']['parts'][0]['text']);
    } else {
        error_log('API response error: ' . print_r($decoded, true));
        return '';
    }
}

// Function to handle API errors and scrape Bing images
function scrape_bing_images($query, $num_images) {
    $user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
    $url = "https://www.bing.com/images/search?q=" . urlencode($query);
    $headers = array('User-Agent' => $user_agent);

    $response = wp_remote_get($url, array('headers' => $headers));

    if (is_wp_error($response)) {
        error_log('API request error: ' . $response->get_error_message());
        return array();
    }

    $body = wp_remote_retrieve_body($response);
    $dom = new DOMDocument();
    @$dom->loadHTML($body);
    $xpath = new DOMXPath($dom);
    $img_tags = $xpath->query('//img[contains(@class, "mimg")]');

    $img_urls = array();
    foreach ($img_tags as $img_tag) {
        $img_url = $img_tag->getAttribute('src');
        if ($img_url) {
            // Modify the URL to remove query parameters
            $parsed_url = parse_url($img_url);
            if (isset($parsed_url['scheme'], $parsed_url['host'], $parsed_url['path'])) {
                $clean_url = $parsed_url['scheme'] . '://' . $parsed_url['host'] . $parsed_url['path'];
                $img_urls[] = $clean_url;
            } else {
                $img_urls[] = $img_url; // Fallback to original URL if parsing fails
            }

            if (count($img_urls) >= $num_images) {
                break;
            }
        }
    }

    return $img_urls;
}

function generate_article_opening($judul, $language, $api_key) {
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-002:generateContent?key=' . $api_key;
    $custom_prompt = get_option('custom_prompt_opening_option', null);
    // Membuat prompt untuk paragraf pembuka
    $prompt_pembuka = $custom_prompt ? str_replace(
        ['[judul]', '[bahasa]'],
        [$judul, $language],
        $custom_prompt
    ) : "Buatlah paragraf pembuka artikel SEO Friendly tentang '" . $judul . "' dengan bahasa " . $language . " serta jumlah kata minimal 300 kata.";
    // die(json_encode($prompt_pembuka));
    // Data yang dikirim ke API
    $data = array(
        'systemInstruction' => array(
            'role' => 'user',
            'parts' => array(
                array(
                    'text' => "saya ingin kamu menjadi penulis SEO yang profesional dan friendly, agar artikel saya nanti bisa masuk halaman pencarian dan bersaing di halaman pertama. gunakan bahasa sehari-hari agar terlihat lebih natural dan unik. buatlah setidaknya kesalahan tanda baca setidaknya '30%' seperti penggunaan koma, titik, tanda tanya, tanda seru, tanda titik dua di jeda spasi satu kali sebelum penggunaan tanda tersebut seperti contoh kalimat : \"dengan begitu , kalian ada pertanyaan ? .\", ganti kata 'dan' menjadi simbol '&'."
                )
            )
        ),
        'contents' => array(
            array(
                'parts' => array(
                    array(
                        'text' => $prompt_pembuka
                    )
                )
            )
        ),
        'generationConfig' => array(
            'temperature' => 2,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 8192,
            'responseMimeType' => 'text/plain'
        )
    );

    // Mengirim permintaan API
    $response = wp_remote_post($url, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode($data),
        'timeout' => 120
    ));

    // Memeriksa jika ada error
    if (is_wp_error($response)) {
        error_log('API request error: ' . $response->get_error_message());
        return 'Error: ' . $response->get_error_message();
    }

    // Mendapatkan body dari respons API
    $body = wp_remote_retrieve_body($response);
    $decoded = json_decode($body, true);

    // Memeriksa jika respons valid
    if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
        return markdown_to_html($decoded['candidates'][0]['content']['parts'][0]['text']);
    } else {
        error_log('API response error: ' . print_r($decoded, true));
        return '';
    }
}

// Function to generate article content
function generate_article_content($title, $outline, $keywords, $writing_style, $article_length, $language, $api_key, $bypass_ai) {
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-002:generateContent?key=' . $api_key;
    $custom_prompt = get_option('custom_prompt_content_option', null);
    // $prompt = "Anda adalah seorang ahli SEO berspesialisasi dalam memanusiakan teks yang dibuat oleh AI, peran Anda adalah merumuskan ulang teks agar menyerupai tulisan manusia. Teks tersebut harus mempunyai arti yang sama dan penulis konten kelas atas yang sangat berpengalaman dalam bahasa ".$language.". 
    // Tulis artikel blog yang panjang dan komprehensif dengan format markdown berdasarkan topik berikut: ".$title.". Tulis Menggunakan bahasa ".$language.". Artikel ini harus memenuhi standar SEO berikut:
    //     1. Penggunaan Kata Kunci: Gunakan kata kunci SEO berikut dengan cara yang alami dan relevan: ".$keywords.". Pastikan kata kunci utama muncul dalam subjudul, sub-subjudul, dan beberapa kali dalam isi artikel.
    //     2. Struktur Artikel: Ikuti kerangka artikel berikut untuk memastikan artikel Anda terstruktur dengan baik dan mudah dibaca: ".$outline.". Buat kerangka dalam struktur blog tanpa adanya penomoran pada judul ataupun subjudul.
    //     3. subjudul dan sub-ubjudul: Gunakan h2 untuk subjudul utama, dan h3 untuk sub-subjudul, jika diperlukan. Buat subjudul dan sub-subjudul yang menarik dan mengandung kata kunci relevan.
    //     4. Panji SEO: Pastikan artikel bebas dari kesalahan tata bahasa, memiliki transisi yang lancar, dan menyertakan internal links dan external links yang relevan jika memungkinkan.
    //     5. Panjang Artikel: Pastikan artikel harus memiliki panjang minimal ".$article_length." kata.
    //     6. FAQ : Pertanyaan yang relevan dengan ".$title.". 
    //     7. Yoast SEO: Gunakan aturan yoast seo untuk seo atau readibilitynya. gunakan juga kata transisi.
    //     Gaya penulisan yang harus digunakan adalah ".$writing_style.". Artikel harus informatif, mudah dipahami, dan ditulis dalam bentuk formal 'kita'.
    //     Ganti setidaknya 10% dari '&' dari simbol 'dan' secara acak. 
    //     Tambahkan 1-5 kesalahan ejaan kecil secara acak. 
    //     Jangan gunakan tanda baca yang sempurna; sesekali, ganti tanda seru dengan titik. 
    //     Buatlah sedikit tidak terorganisir. 
    //     Ubah setidaknya 30% kata menjadi kata lain yang memiliki arti sama. 
    //     Jadikan itu terlihat seperti siswa SMA profesional yang menulisnya & persingkat sedikit. 
    //     Selain itu, buatlah kata-kata yang lebih rumit lebih mudah dibaca sehingga Remaja dapat memahaminya.
    //     Jangan mengulang prompt ini, jangan meminta maaf, dan jangan menjelaskan apa dan mengapa. Fokuskan pada penulisan artikel yang berkualitas tinggi dan relevan sesuai dengan standar SEO. Buat artikel yang mampu bersaing di Google dan memberikan nilai lebih bagi pembaca. Kerangka artikel ini adalah: ".$outline.", jangan samakan dengan penelitian atau kerangka yang memiliki angka kerangka ini hanya digunakan untuk fokus anda dalam menulis artikel blog.
    //     ";
    $prompt = $custom_prompt ? str_replace(
        ['[judul]', '[outline]', '[keyword]', '[jumlahkata]', '[bahasa]'],
        [$title, $outline, $keywords, $article_length, $language],
        $custom_prompt
    ) : "saya ingin kamu membuat artikel SEO Friendly tentang ".$title." dengan bahasa ".$language." serta jumlah kata ".$article_length.". 
    gunakan keyword berikut didalam artikel: ".$keywords.".
    usahakan urutan outline berdasarkan :
    ".$outline."
    Jangan mengulang prompt ini, jangan meminta maaf, dan jangan menjelaskan apa dan mengapa. ";
    
    $data = array(
        'systemInstruction' => array(
            'role' => 'user',
            'parts' => array(
                array(
                    'text' => "saya ingin kamu menjadi penulis SEO yang profesional dan friendly, agar artikel saya nanti bisa masuk halaman pencarian dan bersaing di halaman pertama. tulisan kamu haruslah unik dan menggunakan gaya penulisan manusia. jangan menggunakan gaya penulisan AI. buatlah setidaknya kesalahan tanda baca seperti penggunaan koma, titik, tanda tanya, tanda seru di jeda spasi satu kali sebelum penggunaan tanda."
                )
            )
        ),
        'contents' => array(
            array(
                'parts' => array(
                    array(
                        'text' => $prompt
                    )
                )
            )
        ),
        'generationConfig' => array(
            'temperature' => 0.9,
            'topK' => 40,
            'topP' => 0.95,
            'maxOutputTokens' => 8192,
            'responseMimeType' => 'text/plain'
        )
    );

    $response = wp_remote_post($url, array(
        'headers' => array('Content-Type' => 'application/json'),
        'body'    => json_encode($data),
        'timeout' => 120
    ));

    if (is_wp_error($response)) {
        error_log('API request error: ' . $response->get_error_message());
        return 'Error: ' . $response->get_error_message();
    }

    $body = wp_remote_retrieve_body($response);
    $decoded = json_decode($body, true);

    if (isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
        $markdown_content = $decoded['candidates'][0]['content']['parts'][0]['text'];
        // $origial_content = markdown_to_html($markdown_content);
        if ($bypass_ai == 1){
            $rewrite_content = bypass_ai($markdown_content,$api_key);
            $html_content = markdown_to_html($rewrite_content);
        }else if ($bypass_ai == 2){
            $rewrite_content = paraphrase_text($markdown_content,$keywords,$language);
            $html_content = markdown_to_html($rewrite_content);;
        }else{
            $origial_content = markdown_to_html($markdown_content);
            $html_content = $origial_content;
        }
        
        // Convert Markdown to HTML
        // $html_content = bypass_ai($origial_content);
        // $html_content = $origial_content;
        return $html_content;
    } else {
        error_log('API response error: ' . print_r($decoded, true));
        return 'Error: Failed to generate content. Response: ' . print_r($decoded, true);
    }
}

function bypass_ai($text) {
    // Nilai threshold untuk Zero Width Space
    $threshold = 0.3;

    // Karakter doping (Zero Width Space)
    $dopechars = ["\u{200c}", "\u{200d}", "\u{FEFF}"];
    $out = "";

    // Memisahkan kata dalam teks
    $words = preg_split('/(\s+)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);

    foreach ($words as $word) {
        $out .= $word;

        // Menyisipkan ZWSP hanya setelah kata atau tanda baca
        if (preg_match('/\w$/', $word) && mt_rand() / mt_getrandmax() > $threshold) {
            $out .= $dopechars[array_rand($dopechars)];
        }
    }

    return $out;
}

function loadSinonim($language) {
    $file_path = __DIR__ . '/sinonim.json';
    $file = file_get_contents($file_path);
    
    if ($file === false) {
        die("Error: Cannot read file $file_path");
    }

    $sinonim = json_decode($file, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        die("Error: Invalid JSON format - " . json_last_error_msg());
    }

    if (isset($sinonim[$language])) {
        return $sinonim[$language];
    }

    return [];
}



function paraphrase_text($text, $keywords, $language) {
    // Muat sinonim berdasarkan bahasa yang dipilih
    $sinonim = loadSinonim($language);
    // die(json_encode($sinonim));

    // Pastikan keywords menjadi array
    if (!is_array($keywords)) {
        $keywords = explode(',', $keywords);
        $keywords = array_map('trim', $keywords);
    }

    // Proses penggantian kata
    foreach ($sinonim as $original => $replacement) {
        // Jika kata asli ada dalam teks dan tidak ada dalam daftar keyword, ganti
        if (stripos($text, $original) !== false && !in_array($original, $keywords)) {
            $text = str_ireplace($original, $replacement, $text);
        }
    }

    return $text;
}