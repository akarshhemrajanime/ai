<?php
/**
 * Uninstall script for ContentAI plugin.
 *
 * @package ContentAI
 */

// Prevent direct access
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete plugin options
delete_option('ContentAI_api_key');
delete_option('ContentAI_license_key');
delete_option('ContentAI_license_status');