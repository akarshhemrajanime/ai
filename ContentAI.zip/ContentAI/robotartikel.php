<?php
/*
Plugin Name: ContentAI
Description: Plugin generate artikel dengan API Gemini.
Version: 1.10.1
Author: MirzaDev
*/

defined('ABSPATH') or die('No script kiddies please!');

// Tambahkan ini di bagian atas file plugin Anda
add_filter('site_transient_update_plugins', 'ContentAI_check_for_update');

function ContentAI_check_for_update($transient) {
    $plugin_slug = 'ContentAI';
    $plugin_version = '1.10.0'; // Ganti dengan versi saat ini
    $zip_url = 'https://github.com/akarshhemrajanime/ai/raw/main/ContentAI.zip';

    // Cek apakah transient sudah ada
    if (empty($transient->checked)) {
        return $transient;
    }

    // Ambil informasi versi terbaru dari file ZIP
    $remote_version = get_remote_plugin_version($zip_url);
    if (version_compare($plugin_version, $remote_version, '<')) {
        $plugin_data = array(
            'slug' => $plugin_slug,
            'new_version' => $remote_version,
            'url' => 'https://github.com/akarshhemrajanime/ai', // URL halaman plugin
            'package' => $zip_url, // URL untuk mengunduh paket ZIP
        );

        // Tambahkan informasi pembaruan ke transient
        $transient->response[$plugin_slug] = (object) $plugin_data;
    }

    return $transient;
}

function get_remote_plugin_version($zip_url) {
    // Buat file sementara untuk menyimpan ZIP
    $temp_zip = tempnam(sys_get_temp_dir(), 'plugin_zip');
    
    // Unduh file ZIP
    file_put_contents($temp_zip, file_get_contents($zip_url));

    // Ekstrak file ZIP
    $zip = new ZipArchive;
    if ($zip->open($temp_zip) === TRUE) {
        // Ambil file plugin utama (asumsi bernama ContentAI.php)
        $plugin_file = 'ContentAI.php'; // Sesuaikan dengan nama file plugin Anda
        if ($zip->locateName($plugin_file) !== false) {
            // Dapatkan isi file
            $file_content = $zip->getFromName($plugin_file);
            $zip->close();

            // Ekstrak versi dari header plugin
            if (preg_match('/Version:\s*(\S+)/', $file_content, $matches)) {
                return $matches[1]; // Kembalikan versi yang ditemukan
            }
        }
        $zip->close();
    }

    // Hapus file sementara
    unlink($temp_zip);
    return false; // Kembalikan false jika tidak ditemukan
}

// Fungsi untuk mengunduh dan memperbarui plugin
add_filter('upgrader_pre_install', 'ContentAI_update_plugin', 10, 2);
function ContentAI_update_plugin($pre, $hook_extra) {
    if ($hook_extra['type'] === 'plugin' && $hook_extra['slug'] === 'ContentAI') {
        // Unduh dan instal plugin baru
        $upgrader = new Plugin_Upgrader();
        $upgrader->install('https://github.com/akarshhemrajanime/ai/raw/main/ContentAI.zip');
    }
}

// Include necessary files
include(plugin_dir_path(__FILE__) . 'includes/api-functions.php');
include(plugin_dir_path(__FILE__) . 'includes/wp-functions.php');

// Create admin menu
add_action('admin_menu', 'ContentAI_menu');
add_action('admin_enqueue_scripts', 'ContentAI_enqueue_admin_styles');
add_action('admin_init', 'ContentAI_settings');
// Add a page for generating and posting articles
add_action('admin_menu', 'ContentAI_generate_articles_page');

function ContentAI_enqueue_admin_styles($hook) {
    // Load styles only on ContentAI's admin pages
    if ($hook === 'toplevel_page_ContentAI' || $hook === 'ContentAI_page_generate-articles') {
        wp_enqueue_style(
            'ContentAI-admin-style',
            plugins_url('assets/css/admin-style.css', __FILE__),
            array(), // Dependencies (leave empty if no dependencies)
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/admin-style.css') // File modification time as version
        );
    }
}


function ContentAI_menu() {
    add_menu_page(
        'ContentAI',
        'ContentAI',
        'manage_options',
        'ContentAI',
        'ContentAI_settings_page'
    );
}

function ContentAI_settings_page() {
    ?>
    <div class="wrap ContentAI-settings-page">
        <h1>Pengaturan ContentAI</h1>
        
        <?php
        // Menampilkan pesan error atau sukses
        settings_errors('ContentAI_messages');
        ?>

        <form method="post" action="options.php">
            <?php
            settings_fields('ContentAI_options_group');
            do_settings_sections('ContentAI');
            submit_button('Simpan Pengaturan');
            ?>
        </form>
    </div>
    <?php
}


function ContentAI_settings() {
    // Registrasi pengaturan 'gemini_apis'
    register_setting('ContentAI_options_group', 'gemini_apis');

    // Menambahkan section di halaman pengaturan
    add_settings_section(
        'ContentAI_main_section',
        'Konfigurasi API',
        null,
        'ContentAI'
    );

    // Menambahkan field untuk API Gemini
    add_settings_field(
        'gemini_apis', // Nama field
        'Gemini API Key (Satu per baris)', // Label
        'ContentAI_api_keys_callback', // Callback function
        'ContentAI', // Halaman pengaturan
        'ContentAI_main_section' // Section
    );

    // Menambahkan pesan sukses
    if (isset($_GET['settings-updated'])) {
        add_settings_error('ContentAI_messages', 'ContentAI_message', 'API berhasil disimpan.', 'updated');
    }
}
add_action('admin_init', 'ContentAI_settings');

function ContentAI_api_keys_callback() {
    // Mengambil API Key yang sudah tersimpan dari database
    $api_keys = get_option('gemini_apis', ''); // Nama opsi adalah 'gemini_apis'

    // Menampilkan textarea untuk input API Key, satu per baris
    echo '<textarea name="gemini_apis" rows="10" cols="50">' . esc_textarea($api_keys) . '</textarea>';
    echo '<p class="description">Masukkan beberapa Gemini API Key, satu per baris.</p>';
    echo '<p>pastikan api bisa digunakan agar penggunaan robot artikel bisa berjalan dengan baik.</p>';
}


add_action('admin_menu', 'custom_prompt_menu');

function custom_prompt_menu() {
    // Tambahkan sub-menu di dalam ContentAI
    add_submenu_page(
        'ContentAI',          // Slug menu induk
        'Custom Prompt',         // Judul halaman
        'Custom Prompt',         // Nama menu
        'manage_options',        // Kapasitas
        'custom-prompt',         // Slug
        'custom_prompt_page'     // Fungsi callback
    );
}

function custom_prompt_page() {
    // Default prompts
    $default_opening = "Buatlah paragraf pembuka artikel SEO Friendly tentang '[judul]' dengan bahasa [bahasa] serta jumlah kata minimal 300 kata. 
    Jangan mengulang prompt ini, jangan meminta maaf, dan jangan menjelaskan apa dan mengapa.";
    
    $default_content = "Saya ingin kamu membuat artikel SEO Friendly tentang [judul] dengan bahasa [bahasa] serta jumlah kata [jumlahkata]. 
    Gunakan keyword berikut di dalam artikel: [keyword]. 
    Usahakan urutan outline berdasarkan: [outline]. 
    Jangan mengulang prompt ini, jangan meminta maaf, dan jangan menjelaskan apa dan mengapa.";
    
    $default_outline = "Your first task is to write an in-depth and comprehensive blog post outline for an article about: [judul]. 
    Keep in mind this is also the target keyword ([keyword]) we are trying to rank for so include it and variations of the keyword in the h1,h2,h3 and throughout the article. 
    Create an in-depth blog post outline with every single question or topic a person would have for this blog post topic. 
    Include information specific to the topic you are writing about but also general information about the blog post topic that would be useful for readers. 
    Write in a simple, easy to read tone.

    for the format sample:

    Heading 1
    Heading 2
    Heading 3
    Heading 3
    Heading 2
    Heading 3
    Heading 3
    Heading 2
    Heading 3
    Heading 3
    conclusion

    use the format sample to implement outline.
    Dont repeat this prompt, dont apologize, and dont explain what and why.";

    $opening_prompt = get_option('custom_prompt_opening_option', $default_opening);
    $content_prompt = get_option('custom_prompt_content_option', $default_content);
    $outline_prompt = get_option('custom_prompt_outline_option', $default_outline);
    ?>
    <div class="wrap">
        <h1>Custom Prompt Settings</h1>
        
        <h2>Keterangan Penggunaan Variabel</h2>
        <ul>
            <li><strong>[judul]</strong>: Judul artikel.</li>
            <li><strong>[bahasa]</strong>: Bahasa yang digunakan untuk artikel.</li>
            <li><strong>[outline]</strong>: Outline atau kerangka artikel.</li>
            <li><strong>[keyword]</strong>: Kata kunci yang relevan untuk artikel.</li>
            <li><strong>[jumlahkata]</strong>: Jumlah kata yang diinginkan untuk artikel.</li>
        </ul>

        <form method="post" action="">
            <h2>Generate Outline</h2>
            <textarea id="custom_prompt_outline" name="custom_prompt_outline" rows="5" cols="50"><?php echo esc_textarea($outline_prompt); ?></textarea><br>

            <h2>Generate Artikel Opening</h2>
            <textarea id="custom_prompt_opening" name="custom_prompt_opening" rows="5" cols="50"><?php echo esc_textarea($opening_prompt); ?></textarea><br>
            
            <h2>Generate Artikel Content</h2>
            <textarea id="custom_prompt_content" name="custom_prompt_content" rows="5" cols="50"><?php echo esc_textarea($content_prompt); ?></textarea><br>

            <input type="submit" name="save_custom_prompt" class="button button-primary" value="Simpan Prompt">
        </form>
    </div>
    <?php

    if (isset($_POST['save_custom_prompt'])) {
        // Simpan prompt ke dalam database
        update_option('custom_prompt_opening_option', sanitize_textarea_field($_POST['custom_prompt_opening']));
        update_option('custom_prompt_content_option', sanitize_textarea_field($_POST['custom_prompt_content']));
        update_option('custom_prompt_outline_option', sanitize_textarea_field($_POST['custom_prompt_outline']));
        echo '<div class="updated"><p>Custom prompts disimpan.</p></div>';
    }
}

function ContentAI_generate_articles_page() {
    add_submenu_page(
        'ContentAI',
        'Generate Articles',
        'Generate Articles',
        'manage_options',
        'generate-articles',
        'ContentAI_generate_articles'
    );
}

function ContentAI_generate_articles() {
    ?>
    <div class="wrap">
        <center><h1>Generate and Post Articles</h1></center>
        <form id="generate-articles-form" method="post" action="">
            <?php wp_nonce_field('ContentAI_nonce', 'security'); ?>
            <textarea name="article_titles" rows="5" cols="50" placeholder="Enter article titles, one per line"></textarea>
            <h5>Keywords (Optional)</h5>
            <textarea name="manual_keywords" placeholder="Masukkan kata kunci manual, dipisahkan dengan koma. Jika diisi maka akan mengambil keywords suggestions."></textarea>
            <input type="checkbox" name="auto_insert_image" id="auto_insert_image" value="1" onchange="toggleSaveImage()">
            <label for="auto_insert_image">Add Image in Content</label>
            <div id="save_image_container" style="display: none;">
                <input type="checkbox" name="save_image" id="save_image" value="1">
                <label for="save_image">Simpan Gambar Di Lokal</label>
            </div>

            <input type="checkbox" name="bypass_ai" id="bypass_ai" value="1">Extreame Bypass</input>
            <input type="checkbox" name="bypass_ai" id="bypass_ai" value="2">Sinonim Bypass</input>
            <label for="bypass_ai">Bypass AI</label>
            <input type="checkbox" name="add_related_posts" id="add_related_posts" value="1">
            <label for="add_related_posts">Add Related Post</label>
            
            <h5>Language Article</h5>
            <select name="language">
                <option value="indonesia">Indonesia</option>
                <option value="inggris">English</option>
                <option value="jepang">Jepang</option>
                <option value="korea">Korea</option>
                <option value="Arab Saudi">Arab</option>
            </select>
            <h5>Article Length</h5>
            <select name="article_length">
                <option value="500">500 Kata</option>
                <option value="700">700 Kata</option>
                <option value="1000">1000 Kata</option>
                <option value="1500">1500 Kata</option>
                <option value="2000">2000 Kata</option>
            </select>
            
            <h5>Categories</h5>
            <?php
            $categories = get_wordpress_categories();
            ?>
            <select name="categories[]" multiple="multiple">
                <?php foreach ($categories as $id => $name): ?>
                    <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($name); ?></option>
                <?php endforeach; ?>
            </select>
            <br>
            <input type="date" name="start_date" placeholder="Start Date">
            <input type="date" name="end_date" placeholder="End Date">
            <br>
            <br>
            <input type="submit" name="generate_articles" class="button button-primary" value="Generate and Post Articles">
        </form>
        <br>
        <br>
        <div id="progress-status"></div>
        <div id="loader" style="display:none; text-align:center;">
            <img src="<?php echo plugins_url('assets/images/loader.gif', __FILE__); ?>" alt="Processing..." style="width: 50px; height: 50px;">
        </div>
    </div>

        <script>
        jQuery(document).ready(function($) {
            $('#generate-articles-form').on('submit', function(e) {
                e.preventDefault(); // Prevent the form from submitting the traditional way

                var formData = $(this).serialize(); // Serialize the form data

                // Tampilkan loader dan status
                $('#loader').show();
                $('#progress-status').html('<p>Process started. Please wait...</p>');

                var pollInterval = 5000; // Time in milliseconds to poll for updates

                function fetchStatus() {
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: formData + '&action=ContentAI_generate_articles',
                        success: function(response) {
                            if (response.success) {
                                $('#progress-status').html(response.data);

                                // Check if "All tasks completed" is in the response
                                if (response.data.includes('All tasks completed.')) {
                                    // Sembunyikan loader jika semua tugas selesai
                                    $('#loader').hide();
                                    // Stop polling if all tasks are completed
                                    return;
                                }

                                // Poll for updates every interval
                                setTimeout(fetchStatus, pollInterval);
                            } else {
                                $('#progress-status').html('<div class="error"><p>An error occurred: ' + response.data + '</p></div>');
                                $('#loader').hide(); // Sembunyikan loader jika terjadi error
                            }
                        },
                        error: function(xhr, status, error) {
                            console.log("XHR: ", xhr);
                            console.log("Status: ", status);
                            console.log("Error: ", error);

                            var errorMsg = 'An error occurred.';
                            if (xhr.responseText) {
                                errorMsg = 'An error occurred: ' + xhr.responseText;
                            } else if (status) {
                                errorMsg = 'Status: ' + status;
                            }

                            $('#progress-status').html('<div class="error"><p>' + errorMsg + '</p></div>');
                            $('#loader').hide(); // Sembunyikan loader jika terjadi error
                        }
                    });
                }

                fetchStatus(); // Start polling for updates
            });
        });
        </script>
        <script>
            function toggleSaveImage() {
                var autoInsertImage = document.getElementById("auto_insert_image");
                var saveImageContainer = document.getElementById("save_image_container");
                
                // Tampilkan atau sembunyikan "Simpan Gambar Di Lokal" berdasarkan status checkbox "Add Image in Content"
                saveImageContainer.style.display = autoInsertImage.checked ? "block" : "none";
            }
        </script>
    <?php
}

add_action('wp_ajax_ContentAI_generate_articles', 'ContentAI_generate_articles_ajax');

function ContentAI_generate_articles_ajax() {
    check_ajax_referer('ContentAI_nonce', 'security');
    try {
        // Ambil API key
        $api_keys_raw = get_option('gemini_apis'); // Misalkan ini format multiline
        $api_keys = explode("\r\n", $api_keys_raw); // Pisahkan menjadi array berdasarkan newline
        $api_keys = array_map('trim', $api_keys); // Hapus spasi di sekitar
        $api_keys = array_unique($api_keys); // Hapus duplikat

        // Log API keys untuk debug
        // error_log('API Keys: ' . json_encode($api_keys));

        $titles = explode("\n", sanitize_textarea_field($_POST['article_titles']));
        $titles = array_map('trim', $titles); 
        $titles = array_unique($titles);
        $titles = array_filter($titles);  

        $language = sanitize_text_field($_POST['language']);
        $article_length = intval($_POST['article_length']);
        $writing_style = sanitize_text_field($_POST['writing_style']);
        $selected_categories = isset($_POST['categories']) ? array_map('intval', $_POST['categories']) : array();
        
        $manual_keywords = isset($_POST['manual_keywords']) ? sanitize_text_field($_POST['manual_keywords']) : ''; 
        $auto_insert_image = isset($_POST['auto_insert_image']) ? intval($_POST['auto_insert_image']) : 0;
        $bypass_ai = isset($_POST['bypass_ai']) ? intval($_POST['bypass_ai']) : 0;
        $add_related_posts = isset($_POST['add_related_posts']) ? intval($_POST['add_related_posts']) : 0;
        $saveImage = isset($_POST['save_image']) ? intval($_POST['save_image']) : 0;

        $batch_size = 1; 
        $total_titles = count($titles);
        $batch_count = ceil($total_titles / $batch_size);

        $results = [];
        $response_html = '';

        ob_start();
        
        $api_key_count = count($api_keys); // Hitung jumlah API key
        $api_key_index = 0; // Indeks untuk memilih API key

        for ($i = 0; $i < $batch_count; $i++) {
            $batch_titles = array_slice($titles, $i * $batch_size, $batch_size);

            foreach ($batch_titles as $index => $title) {
                if (!empty($title)) {
                    
                    $existing_post_query = new WP_Query([
                        'title' => $title,
                        'post_type' => 'post',
                        'post_status' => 'any', 
                        'fields' => 'ids' 
                    ]);

                    if ($existing_post_query->have_posts()) {
                        $response_html .= '<div class="gagal"><p>Generate (' . ($i + 1) . '/' . $total_titles . '): Article with the title "' . esc_html($title) . '" already exists in WordPress (any status). Skipping this title.</p></div>';
                    } else {
                        // Pilih API key secara bergantian
                        $api_key = $api_keys[$api_key_index];
                        // die(json_encode($api_key));
                        // Gunakan kata kunci manual jika ada, jika tidak gunakan get_keyword_suggestions
                        $keywords = !empty($manual_keywords) ? explode(',', $manual_keywords) : get_keyword_suggestions($title, $api_key, $language);
                        // die(json_encode($keywords));
                        if (empty($keywords)) {
                            $response_html .= '<div class="gagal"><p>Failed to get keywords for article "' . esc_html($title) . '".</p></div>';
                        } else {
                            $outline = generate_mece_outline($title, $api_key, implode(', ', $keywords), $language);
                            // die(json_encode($outline));
                            if (empty($outline)) {
                                $response_html .= '<div class="gagal"><p>Failed to generate outline for article "' . esc_html($title) . '".</p></div>';
                            } else {
                                $opening = generate_article_opening($title, $language, $api_key);
                                $content = generate_article_content($title, $outline, implode(', ', $keywords), $writing_style, $article_length, $language, $api_key, $bypass_ai);
                                
                                $internal_link = site_url();
                                $final_content = $opening . "\n\n" . $content;
                                
                                $meta_description = wp_trim_words(strip_tags($final_content), 17, '...');
                                $image_count = $auto_insert_image ? 2 : 1;
                                
                                $timezone = new DateTimeZone(wp_timezone_string());
                                $start_date = new DateTime($_POST['start_date'], $timezone);
                                $end_date = new DateTime($_POST['end_date'], $timezone);
                                $interval = $end_date->diff($start_date);
                                $days = rand(0, $interval->days);
                                $random_date = (clone $start_date)->add(new DateInterval('P' . $days . 'D'));
                                $random_time = new DateInterval('PT' . rand(0, 23) . 'H' . rand(0, 59) . 'M');
                                $post_datetime = $random_date->add($random_time);
                                $post_date = $post_datetime->format('Y-m-d H:i:s');
                                
                                $status_code = post_article_to_wordpress($title, $final_content, $selected_categories, $post_date, $keywords[0], $meta_description, $image_count, $add_related_posts,$saveImage);
                                
                                if ($status_code == 201) {
                                    $results[] = [
                                        'title' => $title,
                                        'status' => 'success',
                                        'post_date' => $post_date
                                    ];
                                    $response_html .= '<div class="berhasil"><p>Generate (' . ($i + 1) . '/' . $total_titles . '): Article "' . esc_html($title) . '" has been generated and scheduled for ' . $post_date . '.</p></div>';
                                } else {
                                    $results[] = [
                                        'title' => $title,
                                        'status' => 'error',
                                        'error' => $status_code
                                    ];
                                    $response_html .= '<div class="gagal"><p>Generate (' . ($i + 1) . '/' . $total_titles . '): Failed to generate article "' . esc_html($title) . '". Error: ' . esc_html($status_code) . '</p></div>';
                                }

                                ob_flush();
                                flush();
                            }
                        }
                    }
                }
            }

            // Ubah indeks API key untuk batch berikutnya
            $api_key_index = ($api_key_index + 1) % $api_key_count; // Kembali ke indeks 0 jika sudah mencapai akhir
            sleep(1);
        }
        
        $response_html .= '<div class="all-done"><p>All tasks completed.</p></div>';

        ob_end_clean(); 
        wp_send_json_success($response_html); 
        wp_die(); 
    } catch (Exception $e) {
        // Jika ada kesalahan
        wp_send_json_error('Error: ' . $e->getMessage());
    }

    wp_die(); 
}
